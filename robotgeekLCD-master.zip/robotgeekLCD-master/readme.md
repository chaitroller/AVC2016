        ___________________________________
       |  _______________________________  |
       | |RobotGeek I2C LCD              |\|
       | |  Arduino Library              | |
       | |                               | |
       | |_______________________________|/|
       |___________________________________|
 
   This library will allow use of the RobotGeek IIC LCD
    http://learn.trossenrobotics.com/30-robotgeek-getting-started-guides/dev-kits/57-robotgeek-i2c-lcd-getting-started-guide
    http://www.trossenrobotics.com/robotgeek-lcd
      
 
 
Installation
	Move the folder titled 'RobotGeek' into your Arduino Libaries folder. This is usually under
	
	~Documents/Arduino/libraries
	